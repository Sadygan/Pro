/* function GetBodyScrollTop() { 
    return window.pageYOffset || window.scrollY || (document.documentElement && document.documentElement.scrollTop) || (document.body && document.body.scrollTop) || 0; 
}

jQuery(window).load(function($){
	var widget = jQuery("thead");
	var widgpos = widget.offset();
	jQuery(window).on("scroll", function(e) {
	  if (GetBodyScrollTop() > widgpos.top) {
	    widget.addClass("fix");
	  } else {
	    widget.removeClass("fix");
	  }
	});
});
$(document).ready(function() {
	var twidth = $('table').width();
    $('.fix').css('width',twidth);
	alert(twidth);
}); */

$(document).ready(function() {
	$("table").stickyTableHeaders();
	jQuery('textarea').autoResize({
	     extraSpace : 0
	});
	$('select').chosen();
	/* $('#modalpict').on('show.bs.modal', function (e) {
	  var invoker = e.relatedTarget;
	});
	console.log(invoker); */
	var invoker;
	$('a[data-toggle=modal]').on('click', function(){
		invoker = $(this);
	});
	$('#modalpict a').click(function(){
		var imgsrc=$(this).find('img').attr('src');
		$(invoker).find('img').attr('src',imgsrc);
		$('#modalpict').modal('hide');
		console.log(invoker.attr('src'));
	});
});